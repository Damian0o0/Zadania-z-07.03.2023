package Sklep;
import Sklep.Kwiaciarnia ;
public class Sklep {
    protected String adres;
    protected double powierzchnia;
    protected boolean czyJestWc;
    protected double czynsz;
    public Sklep(String adres, double powierzchnia, boolean czyJestWc, double czynsz) {
        this.adres = adres;
        this.powierzchnia = powierzchnia;
        this.czyJestWc = czyJestWc;
        this.czynsz = czynsz;
    }
    public int iloscPolek() {
        return (int) (powierzchnia / 2);
    }
    public double obliczCzynsz(int liczbaMiesiecy) {
        return czynsz * liczbaMiesiecy;
    }
    @Override
    public String toString() {
        String wc = czyJestWc ? "tak" : "nie";
        return "Sklep o adresie " + adres + ", powierzchni " + powierzchnia + "m², WC: " + wc + ", czynsz: " + czynsz + " zł/miesiąc.";
    }
}

