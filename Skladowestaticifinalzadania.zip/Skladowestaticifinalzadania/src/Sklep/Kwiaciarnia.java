package Sklep;
import Sklep.Sklep;

public class Kwiaciarnia extends Sklep {
    private double powierzchniaZaplecza;
    public Kwiaciarnia(String adres, double powierzchnia, boolean czyJestWc, double czynsz, double powierzchniaZaplecza) {
        super(adres, powierzchnia, czyJestWc, czynsz);
        this.powierzchniaZaplecza = powierzchniaZaplecza;
    }
    @Override
    public int iloscPolek() {
        double calkowitaPowierzchnia = powierzchnia + powierzchniaZaplecza;
        return (int) (calkowitaPowierzchnia / 4);
    }
    @Override
    public String toString() {
        String wcInfo = czyJestWc ? "tak" : "nie";
        return "Kwiaciarnia o adresie " + adres + ", powierzchni " + powierzchnia + "m², zaplecze o powierzchni " + powierzchniaZaplecza + "m², WC: " + wcInfo + ", czynsz: " + czynsz + " zł/miesiąc.";
    }
}