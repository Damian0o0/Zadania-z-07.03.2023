import Sklep.Sklep;
import Sklep.Kwiaciarnia;
public class Main {
    public static void main(String[] args) {
        Kwiaciarnia kwiaciarnia = new Kwiaciarnia("radom 2", 100, false, 300, 50);
        System.out.println("\n" + kwiaciarnia.toString());

        Sklep sklep = new Sklep("radom 1",50,true,500);

        int iloscPolek = sklep.iloscPolek();
        System.out.println("Ilość półek: " + iloscPolek);

        int liczbaMiesiecy = 12;
        double czynsz = 500;
        double obliczCzynsz = sklep.obliczCzynsz(liczbaMiesiecy);
        System.out.println("Czynsz za " + liczbaMiesiecy + " miesięcy: " + obliczCzynsz);
    }
}